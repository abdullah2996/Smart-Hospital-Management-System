#define _CRT_SECURE_NO_WARNINGS
#include "HospitalSystem.h"

short int get_safe_int(const char* prompt, short int min, short int max) {
    short int value;
    while (true) {
        cout << prompt;
        cin >> value;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << " invalid input! please enter a number.\n";
        }
        else if (value < min || value > max) {
            cout << " input must be between " << min << " and " << max << ".\n";
        }
        else {
            cin.ignore(1000, '\n');
            return value;
        }
    }
}

// DoctorLoadBalancer Implementations
void DoctorLoadBalancer::heapify_up(short int index) {
    if (index == 0) return;
    short int parent = (index - 1) / 2;

    if (heap[index].current_load < heap[parent].current_load) {
        swap(heap[index], heap[parent]);
        heapify_up(parent);
    }
}

void DoctorLoadBalancer::heapify_down(short int index) {
    short int left = 2 * index + 1;
    short int right = 2 * index + 2;
    short int smallest = index;

    if (left < size && heap[left].current_load < heap[smallest].current_load)
        smallest = left;

    if (right < size && heap[right].current_load < heap[smallest].current_load)
        smallest = right;

    if (smallest != index) {
        swap(heap[index], heap[smallest]);
        heapify_down(smallest);
    }
}

DoctorLoadBalancer::DoctorLoadBalancer() : size(0) {}

void DoctorLoadBalancer::add_doctor(Doctor d) {
    heap[size] = d;
    heapify_up(size);
    size++;
}

Doctor DoctorLoadBalancer::assign_doctor() {
    if (size == 0) {
        Doctor d;
        d.id = -1;
        return d;
    }
    Doctor selected = heap[0];
    heap[0].current_load++;
    heapify_down(0);
    return selected;
}

void DoctorLoadBalancer::release_doctor(short int doctor_id) {
    for (short int i = 0; i < size; i++) {
        if (heap[i].id == doctor_id && heap[i].current_load > 0) {
            heap[i].current_load--;
            heapify_up(i);
            break;
        }
    }
}

void DoctorLoadBalancer::display_doctors() {
    cout << "\n---- doctor load status ----\n";
    for (short int i = 0; i < size; i++) {
        cout << "id: " << heap[i].id
            << " | name: " << heap[i].name
            << " | specialization: " << heap[i].specialization
            << " | load: " << heap[i].current_load << endl;
    }
}

// PatientHashTable Implementations
short int PatientHashTable::hash_function(short int id) {
    return id % TABLE_SIZE;
}

PatientHashTable::PatientHashTable() {
    for (short int i = 0; i < TABLE_SIZE; i++) {
        table[i] = NULL;
    }
}

void PatientHashTable::insert(short int id, const char* name, short int age, short int severity, const char* disease, short int dept_id) {
    short int index = hash_function(id);
    PatientNode* new_node = new PatientNode;
    new_node->id = id;
    strcpy(new_node->name, name);
    new_node->age = age;
    new_node->severity = severity;
    strcpy(new_node->disease, disease);
    new_node->dept_id = dept_id;
    new_node->next = table[index];
    table[index] = new_node;
}

PatientNode* PatientHashTable::search(short int id) {
    short int index = hash_function(id);
    PatientNode* temp = table[index];
    while (temp != NULL) {
        if (temp->id == id)
            return temp;
        temp = temp->next;
    }
    return NULL;
}

bool PatientHashTable::remove(short int id) {
    short int index = hash_function(id);
    PatientNode* temp = table[index];
    PatientNode* prev = NULL;

    while (temp != NULL && temp->id != id) {
        prev = temp;
        temp = temp->next;
    }

    if (temp == NULL) return false;

    if (prev == NULL) {
        table[index] = temp->next;
    }
    else {
        prev->next = temp->next;
    }
    delete temp;
    return true;
}

void PatientHashTable::show_critical_patients() {
    cout << "\n---- critical patients (severity 5) ----\n";
    for (short int i = 0; i < TABLE_SIZE; i++) {
        PatientNode* temp = table[i];
        while (temp != NULL) {
            if (temp->severity == 5) {
                cout << "id: " << temp->id << " | name: " << temp->name << " | disease: " << temp->disease << "\n";
            }
            temp = temp->next;
        }
    }
}

void PatientHashTable::disease_frequency_report() {
    char diseases[100][100];
    short int count[100] = { 0 };
    short int unique = 0;

    for (short int i = 0; i < TABLE_SIZE; i++) {
        PatientNode* temp = table[i];
        while (temp != NULL) {
            bool found = false;
            for (short int j = 0; j < unique; j++) {
                if (strcmp(diseases[j], temp->disease) == 0) {
                    count[j]++;
                    found = true;
                    break;
                }
            }

            if (!found) {
                strcpy(diseases[unique], temp->disease);
                count[unique] = 1;
                unique++;
            }
            temp = temp->next;
        }
    }

    cout << "\n---- disease frequency report ----\n";
    for (short int i = 0; i < unique; i++) {
        cout << diseases[i] << " : " << count[i] << " patients\n";
    }
}

void PatientHashTable::display_all() {
    cout << "\n---- all patients ----\n";
    for (short int i = 0; i < TABLE_SIZE; i++) {
        PatientNode* temp = table[i];
        while (temp != NULL) {
            cout << "id: " << temp->id << " | name: " << temp->name
                << " | age: " << temp->age << " | severity: " << temp->severity
                << " | disease: " << temp->disease << " | dept: " << temp->dept_id << "\n";
            temp = temp->next;
        }
    }
}

void PatientHashTable::save_to_file() {
    ofstream file("patients.txt");
    for (short int i = 0; i < TABLE_SIZE; i++) {
        PatientNode* temp = table[i];
        while (temp != NULL) {
            file << temp->id << "," << temp->name << "," << temp->age << ","
                << temp->severity << "," << temp->disease << "," << temp->dept_id << "\n";
            temp = temp->next;
        }
    }
    file.close();
}

void PatientHashTable::load_from_file() {
    ifstream file("patients.txt");
    if (!file) return;

    short int id, age, severity, dept_id;
    char name[50], disease[100];
    char line[256];

    while (file.getline(line, 256)) {
        char* token = strtok(line, ",");
        if (token) id = atoi(token);

        token = strtok(NULL, ",");
        if (token) strcpy(name, token);

        token = strtok(NULL, ",");
        if (token) age = atoi(token);

        token = strtok(NULL, ",");
        if (token) severity = atoi(token);

        token = strtok(NULL, ",");
        if (token) strcpy(disease, token);

        token = strtok(NULL, ",");
        if (token) dept_id = atoi(token);

        insert(id, name, age, severity, disease, dept_id);
    }
    file.close();
}

// PriorityQueue Implementations
void PriorityQueue::heapify_up(short int index) {
    if (index == 0) return;
    short int parent = (index - 1) / 2;

    if (heap[index].severity > heap[parent].severity) {
        PriorityPatient temp = heap[index];
        heap[index] = heap[parent];
        heap[parent] = temp;
        heapify_up(parent);
    }
}

void PriorityQueue::heapify_down(short int index) {
    short int left = 2 * index + 1;
    short int right = 2 * index + 2;
    short int largest = index;

    if (left < size && heap[left].severity > heap[largest].severity)
        largest = left;

    if (right < size && heap[right].severity > heap[largest].severity)
        largest = right;

    if (largest != index) {
        PriorityPatient temp = heap[index];
        heap[index] = heap[largest];
        heap[largest] = temp;
        heapify_down(largest);
    }
}

PriorityQueue::PriorityQueue() : size(0) {}

void PriorityQueue::enqueue(short int patient_id, short int severity) {
    if (size >= 100) {
        cout << "queue is full!\n";
        return;
    }
    heap[size].patient_id = patient_id;
    heap[size].severity = severity;
    heapify_up(size);
    size++;
    cout << "patient " << patient_id << " added to queue (severity: " << severity << ")\n";
}

short int PriorityQueue::dequeue() {
    if (size == 0) {
        cout << "queue is empty!\n";
        return -1;
    }

    short int patient_id = heap[0].patient_id;
    heap[0] = heap[size - 1];
    size--;
    heapify_down(0);

    return patient_id;
}

bool PriorityQueue::is_empty() {
    return size == 0;
}

void PriorityQueue::display() {
    cout << "\n---- priority queue ----\n";
    for (short int i = 0; i < size; i++) {
        cout << "patient id: " << heap[i].patient_id
            << " | severity: " << heap[i].severity << "\n";
    }
}

// ReferralGraph Implementations
void ReferralGraph::dfs_util(short int dept, bool visited[]) {
    visited[dept] = true;
    cout << dept << " ";

    GraphNode* temp = adj_list[dept];
    while (temp != NULL) {
        if (!visited[temp->dept_id]) {
            dfs_util(temp->dept_id, visited);
        }
        temp = temp->next;
    }
}

ReferralGraph::ReferralGraph() {
    for (short int i = 0; i < MAX_DEPT; i++) {
        adj_list[i] = NULL;
    }
}

void ReferralGraph::add_referral(short int from, short int to, bool silent) {
    if (from >= MAX_DEPT || to >= MAX_DEPT) return;

    GraphNode* a = new GraphNode;
    a->dept_id = to;
    a->next = adj_list[from];
    adj_list[from] = a;

    GraphNode* b = new GraphNode;
    b->dept_id = from;
    b->next = adj_list[to];
    adj_list[to] = b;

    if (!silent) {
        cout << "referral added between dept " << from << " and dept " << to << "\n";
    }
}

void ReferralGraph::display_graph() {
    cout << "\n---- referral network ----\n";
    for (short int i = 0; i < MAX_DEPT; i++) {
        if (adj_list[i] != NULL) {
            cout << "department " << i << " refers to: ";
            GraphNode* temp = adj_list[i];
            while (temp != NULL) {
                cout << temp->dept_id << " ";
                temp = temp->next;
            }
            cout << "\n";
        }
    }
}

void ReferralGraph::bfs(short int start) {
    bool visited[MAX_DEPT] = { false };
    short int queue[MAX_DEPT];
    short int front = 0, rear = 0;

    visited[start] = true;
    queue[rear++] = start;

    cout << "\nbfs traversal from department " << start << ": ";

    while (front < rear) {
        short int current = queue[front++];
        cout << current << " ";

        GraphNode* temp = adj_list[current];
        while (temp != NULL) {
            if (!visited[temp->dept_id]) {
                visited[temp->dept_id] = true;
                queue[rear++] = temp->dept_id;
            }
            temp = temp->next;
        }
    }
    cout << "\n";
}

void ReferralGraph::dfs(short int start) {
    bool visited[MAX_DEPT] = { false };
    cout << "\ndfs traversal from department " << start << ": ";
    dfs_util(start, visited);
    cout << "\n";
}

void ReferralGraph::dijkstra(short int src) {
    const short int INF = 30000;
    int dist[MAX_DEPT];
    bool visited[MAX_DEPT];
    short int prev[MAX_DEPT];

    for (short int i = 0; i < MAX_DEPT; i++) {
        dist[i] = INF;
        visited[i] = false;
        prev[i] = -1;
    }
    dist[src] = 0;

    for (short int count = 0; count < MAX_DEPT; count++) {
        short int u = -1;
        for (short int i = 0; i < MAX_DEPT; i++) {
            if (!visited[i] && (u == -1 || dist[i] < dist[u])) u = i;
        }

        if (u == -1 || dist[u] == INF) break;
        visited[u] = true;

        GraphNode* temp = adj_list[u];
        while (temp) {
            short int v = temp->dept_id;
            short int weight = 1;
            if (dist[u] + weight < dist[v]) {
                dist[v] = dist[u] + weight;
                prev[v] = u;
            }
            temp = temp->next;
        }
    }

    for (short int i = 0; i < MAX_DEPT; i++) {
        if (dist[i] == INF)
            cout << "dept " << i << " : unreachable\n";
        else
            cout << "dept " << i << " : distance = " << dist[i] << "\n";
    }
}

// ActionStack Implementations
ActionStack::ActionStack() : top(NULL) {}

void ActionStack::push(const char* action, short int patient_id) {
    ActionNode* new_node = new ActionNode;
    strcpy(new_node->action, action);
    new_node->patient_id = patient_id;
    new_node->next = top;
    top = new_node;
}

bool ActionStack::pop(char* action, short int& patient_id) {
    if (top == NULL) return false;

    strcpy(action, top->action);
    patient_id = top->patient_id;

    ActionNode* temp = top;
    top = top->next;
    delete temp;

    return true;
}

void ActionStack::display() {
    cout << "\n --- action history ----\n";
    ActionNode* temp = top;
    while (temp != NULL) {
        cout << temp->action << " patient id: " << temp->patient_id << "\n";
        temp = temp->next;
    }
}

bool ActionStack::is_empty() {
    return top == NULL;
}

// HospitalSystem Implementations
void HospitalSystem::save_doctors() {
    ofstream file("doctors.txt");
    for (short int i = 0; i < doctor_count; i++) {
        file << doctors[i].id << "," << doctors[i].name << ","
            << doctors[i].specialization << "," << doctors[i].current_load << "\n";
    }
    file.close();
}

void HospitalSystem::load_departments() {
    ifstream file("departments.txt");
    if (!file) return;

    while (dept_count < 10 && file >> departments[dept_count].id) {
        file.ignore();
        file.getline(departments[dept_count].name, 50, ',');
        file >> departments[dept_count].capacity;
        file.ignore();
        file >> departments[dept_count].current_patients;
        file.ignore();
        dept_count++;
    }
    file.close();
}

void HospitalSystem::save_departments() {
    ofstream file("departments.txt");
    for (short int i = 0; i < dept_count; i++) {
        file << departments[i].id << "," << departments[i].name << ","
            << departments[i].capacity << "," << departments[i].current_patients << "\n";
    }
    file.close();
}

HospitalSystem::HospitalSystem() : doctor_count(0), dept_count(0) {
    patients.load_from_file();
    load_doctors_from_file();
    load_referrals_from_file();
    load_departments();

    for (int i = 0; i < 1000; i++)
        patient_doctor[i] = -1;
}

void HospitalSystem::add_patient() {
    short int id, age, severity, dept_id;
    char name[50], disease[100];

    id = get_safe_int("\nenter patient id: ", 1, 9999);
    cout << "enter name: ";
    cin.getline(name, 50);
    age = get_safe_int("enter age: ", 0, 120);
    severity = get_safe_int("enter severity (1-5): ", 1, 5);
    cout << "enter disease: ";
    cin.getline(disease, 100);
    dept_id = get_safe_int("enter department id: ", 0, 9);

    patients.insert(id, name, age, severity, disease, dept_id);
    history.push("added patient", id);
    cout << "patient added successfully!\n";
}

void HospitalSystem::delete_patient() {
    short int id;
    id = get_safe_int("\nenter patient id to delete: ", 1, 9999);

    if (patients.remove(id)) {
        history.push("deleted patient", id);
        cout << "patient deleted successfully!\n";
    }
    else {
        cout << "patient not found!\n";
    }
}

void HospitalSystem::search_patient() {
    short int id;
    id = get_safe_int("\nenter patient id: ", 1, 9999);

    PatientNode* p = patients.search(id);
    if (p) {
        cout << "\n--- patient found ---\n";
        cout << "id: " << p->id << "\nname: " << p->name
            << "\nage: " << p->age << "\nseverity: " << p->severity
            << "\ndisease: " << p->disease << "\ndepartment: " << p->dept_id << "\n";
    }
    else {
        cout << "patient not found!\n";
    }
}

void HospitalSystem::add_to_queue() {
    short int id;
    id = get_safe_int("\nenter patient id to add to queue: ", 1, 9999);

    PatientNode* p = patients.search(id);
    if (p) {
        queue.enqueue(id, p->severity);
    }
    else {
        cout << "patient not found!\n";
    }
}

void HospitalSystem::treat_next_patient() {
    short int patient_id = queue.dequeue();
    if (patient_id == -1) return;

    cout << "treating patient id: " << patient_id << "\n";

    short int doctor_id = patient_doctor[patient_id];

    if (doctor_id != -1) {
        doctor_balancer.release_doctor(doctor_id);

        for (int i = 0; i < doctor_count; i++) {
            if (doctors[i].id == doctor_id && doctors[i].current_load > 0) {
                doctors[i].current_load--;
                break;
            }
        }
        patient_doctor[patient_id] = -1;
    }

    history.push("treated patient", patient_id);
}

void HospitalSystem::add_doctor() {
    if (doctor_count >= 100) {
        cout << "doctor limit reached!\n";
        return;
    }

    doctors[doctor_count].id = get_safe_int("\nenter doctor id: ", 1, 9999);
    cin.ignore();
    cout << "enter name: ";
    cin.getline(doctors[doctor_count].name, 50);
    cout << "enter specialization: ";
    cin.getline(doctors[doctor_count].specialization, 50);
    doctors[doctor_count].current_load = 0;

    doctor_balancer.add_doctor(doctors[doctor_count]);
    doctor_count++;

    cout << "doctor added successfully!\n";
    save_doctors();
}

void HospitalSystem::load_doctors_from_file() {
    ifstream file("doctors.txt");
    if (!file) return;

    char line[256];

    while (doctor_count < 50 && file.getline(line, 256)) {
        Doctor d;

        char* token = strtok(line, ",");
        if (token) d.id = atoi(token);

        token = strtok(NULL, ",");
        if (token) strcpy(d.name, token);

        token = strtok(NULL, ",");
        if (token) strcpy(d.specialization, token);

        token = strtok(NULL, ",");
        if (token) d.current_load = atoi(token);

        doctors[doctor_count++] = d;
        doctor_balancer.add_doctor(d);
    }
    file.close();
}

void HospitalSystem::assign_doctor_to_patient() {
    short int patient_id;
    patient_id = get_safe_int("\nenter patient id: ", 1, 9999);

    PatientNode* p = patients.search(patient_id);
    if (!p) {
        cout << "patient not found!\n";
        return;
    }

    Doctor d = doctor_balancer.assign_doctor();

    if (d.id == -1) {
        cout << "no doctors available!\n";
        return;
    }

    patient_doctor[patient_id] = d.id;

    for (int i = 0; i < doctor_count; i++) {
        if (doctors[i].id == d.id) {
            doctors[i].current_load = d.current_load;
            break;
        }
    }

    cout << "\ndoctor assigned successfully!\n";
    cout << "doctor id: " << d.id
        << "\nname: " << d.name
        << "\nspecialization: " << d.specialization
        << "\nupdated load: " << d.current_load << endl;

    history.push("doctor assigned", patient_id);
}

void HospitalSystem::view_queue() {
    queue.display();
}

void HospitalSystem::view_all_patients() {
    patients.display_all();
}

void HospitalSystem::show_critical_patients() {
    patients.show_critical_patients();
}

void HospitalSystem::show_disease_analytics() {
    patients.disease_frequency_report();
}

void HospitalSystem::add_referral() {
    short int from, to;
    from = get_safe_int("\nenter source department id: ", 1, 9999);
    to = get_safe_int("enter destination department id: ", 1, 9999);
    referrals.add_referral(from, to, false);
}

void HospitalSystem::load_referrals_from_file() {
    ifstream file("referrals.txt");
    if (!file) return;

    short int u, v;
    while (file >> u >> v) {
        referrals.add_referral(u, v, true);
    }
    file.close();
}

void HospitalSystem::view_referral_network() {
    referrals.display_graph();
}

void HospitalSystem::traverse_bfs() {
    short int start;
    start = get_safe_int("\nenter starting department id: ", 1, 9999);
    referrals.bfs(start);
}

void HospitalSystem::traverse_dfs() {
    short int start;
    start = get_safe_int("\nenter starting department id: ", 1, 9999);
    referrals.dfs(start);
}

void HospitalSystem::shortest_referral_path() {
    short int start;
    start = get_safe_int("\nenter source department id: ", 1, 9999);
    referrals.dijkstra(start);
}

void HospitalSystem::view_history() {
    history.display();
}

void HospitalSystem::undo_last_action() {
    char action[100];
    short int patient_id;

    if (history.pop(action, patient_id)) {
        cout << "undoing: " << action << " (patient id: " << patient_id << ")\n";
    }
    else {
        cout << "no actions to undo!\n";
    }
}

void HospitalSystem::save_and_exit() {
    patients.save_to_file();
    save_doctors();
    save_departments();
    cout << "data saved. exit.\n";
}