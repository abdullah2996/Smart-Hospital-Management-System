#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;


short int get_safe_int(const char* prompt, short int min = -32768, short int max = 32767) {
    short int value;
    while (true) {
        cout << prompt;
        cin >> value;

        if (cin.fail()) {
            cin.clear();
            cin.ignore(1000, '\n');
            cout << " invalid input! please enter a number.\n";
        }
        else if (value < min || value > max) {
            cout << " input must be between " << min << " and " << max << ".\n";
        }
        else {
            cin.ignore(1000, '\n');
            return value;
        }
    }
}

// PATIENT NODE
struct PatientNode {
    short int id;
    char name[50];
    short int age;
    short int severity; 
    char disease[100];
    short int dept_id;
    PatientNode* next;
};

//  DOCTOR STRUCTURE 
struct Doctor {
    short int id;
    char name[50];
    char specialization[50];
    short int current_load;
};

//  DOCTOR LOAD BALANCER (MIN HEAP) 
class DoctorLoadBalancer {
private:
    Doctor heap[100];
    short int size;

    void heapify_up(short int index) {
        if (index == 0) return;
        short int parent = (index - 1) / 2;

        if (heap[index].current_load < heap[parent].current_load) {
            swap(heap[index], heap[parent]);
            heapify_up(parent);
        }
    }

    void heapify_down(short int index) {
        short int left = 2 * index + 1;
        short int right = 2 * index + 2;
        short int smallest = index;

        if (left < size && heap[left].current_load < heap[smallest].current_load)
            smallest = left;

        if (right < size && heap[right].current_load < heap[smallest].current_load)
            smallest = right;

        if (smallest != index) {
            swap(heap[index], heap[smallest]);
            heapify_down(smallest);
        }
    }

public:
    DoctorLoadBalancer() : size(0) {}

    void add_doctor(Doctor d) {
        heap[size] = d;
        heapify_up(size);
        size++;
    }

    Doctor assign_doctor() {
        if (size == 0) {
            Doctor d; 
            d.id = -1; 
            return d;
        }
        Doctor selected = heap[0];
        heap[0].current_load++;
        heapify_down(0);
        return selected;
    }

    void release_doctor(short int doctor_id) {
        for (short int i = 0; i < size; i++) {
            if (heap[i].id == doctor_id && heap[i].current_load > 0) {
                heap[i].current_load--;
                heapify_up(i);
                break;
            }
        }
    }

    void display_doctors() {
        cout << "\n---- doctor load status ----\n";
        for (short int i = 0; i < size; i++) {
            cout << "id: " << heap[i].id
                << " | name: " << heap[i].name
                << " | specialization: " << heap[i].specialization
                << " | load: " << heap[i].current_load << endl;
        }
    }
};

//  DEPARTMENT STRUCTURE 
struct Department {
    short int id;
    char name[50];
    short int capacity;
    short int current_patients;
};

//  PATIENT HASH TABLE 
class PatientHashTable {
private:
    static const short int TABLE_SIZE = 100;
    PatientNode* table[TABLE_SIZE];

    short int hash_function(short int id) {
        return id % TABLE_SIZE;
    }

public:
    PatientHashTable() {
        for (short int i = 0; i < TABLE_SIZE; i++) {
            table[i] = NULL;
        }
    }

    void insert(short int id, const char* name, short int age, short int severity, const char* disease, short int dept_id) {
        short int index = hash_function(id);
        PatientNode* new_node = new PatientNode;
        new_node->id = id;
        strcpy(new_node->name, name);
        new_node->age = age;
        new_node->severity = severity;
        strcpy(new_node->disease, disease);
        new_node->dept_id = dept_id;
        new_node->next = table[index];
        table[index] = new_node;
    }

    PatientNode* search(short int id) {
        short int index = hash_function(id);
        PatientNode* temp = table[index];
        while (temp != NULL) {
            if (temp->id == id)
                return temp;
            temp = temp->next;
        }
        return NULL;
    }

    bool remove(short int id) {
        short int index = hash_function(id);
        PatientNode* temp = table[index];
        PatientNode* prev = NULL;

        while (temp != NULL && temp->id != id) {
            prev = temp;
            temp = temp->next;
        }

        if (temp == NULL) return false;

        if (prev == NULL) {
            table[index] = temp->next;
        }
        else {
            prev->next = temp->next;
        }
        delete temp;
        return true;
    }

    void show_critical_patients() {
        cout << "\n---- critical patients (severity 5) ----\n";
        for (short int i = 0; i < TABLE_SIZE; i++) {
            PatientNode* temp = table[i];
            while (temp != NULL) {
                if (temp->severity == 5) {
                    cout << "id: " << temp->id << " | name: " << temp->name << " | disease: " << temp->disease << "\n";
                }
                temp = temp->next;
            }
        }
    }

    void disease_frequency_report() {
        char diseases[100][100];
        short int count[100] = { 0 };
        short int unique = 0;

        for (short int i = 0; i < TABLE_SIZE; i++) {
            PatientNode* temp = table[i];
            while (temp != NULL) {
                bool found = false;
                for (short int j = 0; j < unique; j++) {
                    if (strcmp(diseases[j], temp->disease) == 0) {
                        count[j]++;
                        found = true;
                        break;
                    }
                }

                if (!found) {
                    strcpy(diseases[unique], temp->disease);
                    count[unique] = 1;
                    unique++;
                }
                temp = temp->next;
            }
        }

        cout << "\n---- disease frequency report ----\n";
        for (short int i = 0; i < unique; i++) {
            cout << diseases[i] << " : " << count[i] << " patients\n";
        }
    }

    void display_all() {
        cout << "\n---- all patients ----\n";
        for (short int i = 0; i < TABLE_SIZE; i++) {
            PatientNode* temp = table[i];
            while (temp != NULL) {
                cout << "id: " << temp->id << " | name: " << temp->name
                    << " | age: " << temp->age << " | severity: " << temp->severity
                    << " | disease: " << temp->disease << " | dept: " << temp->dept_id << "\n";
                temp = temp->next;
            }
        }
    }

    void save_to_file() {
        ofstream file("patients.txt");
        for (short int i = 0; i < TABLE_SIZE; i++) {
            PatientNode* temp = table[i];
            while (temp != NULL) {
                file << temp->id << "," << temp->name << "," << temp->age << ","
                    << temp->severity << "," << temp->disease << "," << temp->dept_id << "\n";
                temp = temp->next;
            }
        }
        file.close();
    }

    void load_from_file() {
        ifstream file("patients.txt");
        if (!file) return;

        short int id, age, severity, dept_id;
        char name[50], disease[100];
        char line[256];

        while (file.getline(line, 256)) {
            char* token = strtok(line, ",");
            if (token) id = atoi(token);

            token = strtok(NULL, ",");
            if (token) strcpy(name, token);

            token = strtok(NULL, ",");
            if (token) age = atoi(token);

            token = strtok(NULL, ",");
            if (token) severity = atoi(token);

            token = strtok(NULL, ",");
            if (token) strcpy(disease, token);

            token = strtok(NULL, ",");
            if (token) dept_id = atoi(token);

            insert(id, name, age, severity, disease, dept_id);
        }
        file.close();
    }
};

//  PRIORITY QUEUE (MAX HEAP) 
struct PriorityPatient {
    short int patient_id;
    short int severity;
};

class PriorityQueue {
private:
    PriorityPatient heap[100];
    short int size;

    void heapify_up(short int index) {
        if (index == 0) return;
        short int parent = (index - 1) / 2;

        if (heap[index].severity > heap[parent].severity) {
            PriorityPatient temp = heap[index];
            heap[index] = heap[parent];
            heap[parent] = temp;
            heapify_up(parent);
        }
    }

    void heapify_down(short int index) {
        short int left = 2 * index + 1;
        short int right = 2 * index + 2;
        short int largest = index;

        if (left < size && heap[left].severity > heap[largest].severity)
            largest = left;

        if (right < size && heap[right].severity > heap[largest].severity)
            largest = right;

        if (largest != index) {
            PriorityPatient temp = heap[index];
            heap[index] = heap[largest];
            heap[largest] = temp;
            heapify_down(largest);
        }
    }

public:
    PriorityQueue() : size(0) {}

    void enqueue(short int patient_id, short int severity) {
        if (size >= 100) {
            cout << "queue is full!\n";
            return;
        }
        heap[size].patient_id = patient_id;
        heap[size].severity = severity;
        heapify_up(size);
        size++;
        cout << "patient " << patient_id << " added to queue (severity: " << severity << ")\n";
    }

    short int dequeue() {
        if (size == 0) {
            cout << "queue is empty!\n";
            return -1;
        }

        short int patient_id = heap[0].patient_id;
        heap[0] = heap[size - 1];
        size--;
        heapify_down(0);

        return patient_id;
    }

    bool is_empty() {
        return size == 0;
    }

    void display() {
        cout << "\n---- priority queue ----\n";
        for (short int i = 0; i < size; i++) {
            cout << "patient id: " << heap[i].patient_id
                << " | severity: " << heap[i].severity << "\n";
        }
    }
};

//  GRAPH FOR REFERRAL NETWORK 
struct GraphNode {
    short int dept_id;
    GraphNode* next;
};

class ReferralGraph {
private:
    static const short int MAX_DEPT = 10;
    GraphNode* adj_list[MAX_DEPT];

    void dfs_util(short int dept, bool visited[]) {
        visited[dept] = true;
        cout << dept << " ";

        GraphNode* temp = adj_list[dept];
        while (temp != NULL) {
            if (!visited[temp->dept_id]) {
                dfs_util(temp->dept_id, visited);
            }
            temp = temp->next;
        }
    }

public:
    ReferralGraph() {
        for (short int i = 0; i < MAX_DEPT; i++) {
            adj_list[i] = NULL;
        }
    }

    void add_referral(short int from, short int to, bool silent = false) {
        if (from >= MAX_DEPT || to >= MAX_DEPT) return;

        GraphNode* a = new GraphNode;
        a->dept_id = to;
        a->next = adj_list[from];
        adj_list[from] = a;

        GraphNode* b = new GraphNode;
        b->dept_id = from;
        b->next = adj_list[to];
        adj_list[to] = b;

        if (!silent) {
            cout << "referral added between dept " << from << " and dept " << to << "\n";
        }
    }

    void display_graph() {
        cout << "\n---- referral network ----\n";
        for (short int i = 0; i < MAX_DEPT; i++) {
            if (adj_list[i] != NULL) {
                cout << "department " << i << " refers to: ";
                GraphNode* temp = adj_list[i];
                while (temp != NULL) {
                    cout << temp->dept_id << " ";
                    temp = temp->next;
                }
                cout << "\n";
            }
        }
    }

    void bfs(short int start) {
        bool visited[MAX_DEPT] = { false };
        short int queue[MAX_DEPT];
        short int front = 0, rear = 0;

        visited[start] = true;
        queue[rear++] = start;

        cout << "\nbfs traversal from department " << start << ": ";

        while (front < rear) {
            short int current = queue[front++];
            cout << current << " ";

            GraphNode* temp = adj_list[current];
            while (temp != NULL) {
                if (!visited[temp->dept_id]) {
                    visited[temp->dept_id] = true;
                    queue[rear++] = temp->dept_id;
                }
                temp = temp->next;
            }
        }
        cout << "\n";
    }

    void dfs(short int start) {
        bool visited[MAX_DEPT] = { false };
        cout << "\ndfs traversal from department " << start << ": ";
        dfs_util(start, visited);
        cout << "\n";
    }

    void dijkstra(short int src) {
        const short int INF = 30000;
        int dist[MAX_DEPT];
        bool visited[MAX_DEPT];
        short int prev[MAX_DEPT];

        for (short int i = 0; i < MAX_DEPT; i++) {
            dist[i] = INF;
            visited[i] = false;
            prev[i] = -1;
        }
        dist[src] = 0;

        for (short int count = 0; count < MAX_DEPT; count++) {
            short int u = -1;
            for (short int i = 0; i < MAX_DEPT; i++) {
                if (!visited[i] && (u == -1 || dist[i] < dist[u])) u = i;
            }

            if (u == -1 || dist[u] == INF) break;
            visited[u] = true;

            GraphNode* temp = adj_list[u];
            while (temp) {
                short int v = temp->dept_id;
                short int weight = 1; 
                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    prev[v] = u;
                }
                temp = temp->next;
            }
        }

        for (short int i = 0; i < MAX_DEPT; i++) {
            if (dist[i] == INF)
                cout << "dept " << i << " : unreachable\n";
            else
                cout << "dept " << i << " : distance = " << dist[i] << "\n";
        }
    }
};

//  STACK FOR UNDO 
struct ActionNode {
    char action[100];
    short int patient_id;
    ActionNode* next;
};

class ActionStack {
private:
    ActionNode* top;

public:
    ActionStack() : top(NULL) {}

    void push(const char* action, short int patient_id) {
        ActionNode* new_node = new ActionNode;
        strcpy(new_node->action, action);
        new_node->patient_id = patient_id;
        new_node->next = top;
        top = new_node;
    }

    bool pop(char* action, short int& patient_id) {
        if (top == NULL) return false;

        strcpy(action, top->action);
        patient_id = top->patient_id;

        ActionNode* temp = top;
        top = top->next;
        delete temp;

        return true;
    }

    void display() {
        cout << "\n --- action history ----\n";
        ActionNode* temp = top;
        while (temp != NULL) {
            cout << temp->action << " patient id: " << temp->patient_id << "\n";
            temp = temp->next;
        }
    }

    bool is_empty() {
        return top == NULL;
    }
};

//  MAIN SYSTEM 
class HospitalSystem {
private:
    PatientHashTable patients;
    Doctor doctors[100];
    DoctorLoadBalancer doctor_balancer;
    Department departments[100];
    PriorityQueue queue;
    ReferralGraph referrals;
    ActionStack history;
    short int doctor_count;
    short int dept_count;
    short int patient_doctor[1000]; 

    void save_doctors() {
        ofstream file("doctors.txt");
        for (short int i = 0; i < doctor_count; i++) {
            file << doctors[i].id << "," << doctors[i].name << ","
                << doctors[i].specialization << "," << doctors[i].current_load << "\n";
        }
        file.close();
    }

    void load_departments() {
        ifstream file("departments.txt");
        if (!file) return;

        while (dept_count < 10 && file >> departments[dept_count].id) {
            file.ignore();
            file.getline(departments[dept_count].name, 50, ',');
            file >> departments[dept_count].capacity;
            file.ignore();
            file >> departments[dept_count].current_patients;
            file.ignore();
            dept_count++;
        }
        file.close();
    }

    void save_departments() {
        ofstream file("departments.txt");
        for (short int i = 0; i < dept_count; i++) {
            file << departments[i].id << "," << departments[i].name << ","
                << departments[i].capacity << "," << departments[i].current_patients << "\n";
        }
        file.close();
    }

public:
    HospitalSystem() : doctor_count(0), dept_count(0) {
        patients.load_from_file();
        load_doctors_from_file();
        load_referrals_from_file();
        load_departments();

        for (int i = 0; i < 1000; i++)
            patient_doctor[i] = -1;
    }

    void add_patient() {
        short int id, age, severity, dept_id;
        char name[50], disease[100];

        id = get_safe_int("\nenter patient id: ", 1, 9999);
        cout << "enter name: ";
        cin.getline(name, 50);
        age = get_safe_int("enter age: ", 0, 120);
        severity = get_safe_int("enter severity (1-5): ", 1, 5);
        cout << "enter disease: ";
        cin.getline(disease, 100);
        dept_id = get_safe_int("enter department id: ", 0, 9);

        patients.insert(id, name, age, severity, disease, dept_id);
        history.push("added patient", id);
        cout << "patient added successfully!\n";
    }

    void delete_patient() {
        short int id;
        id = get_safe_int("\nenter patient id to delete: ", 1, 9999);

        if (patients.remove(id)) {
            history.push("deleted patient", id);
            cout << "patient deleted successfully!\n";
        }
        else {
            cout << "patient not found!\n";
        }
    }

    void search_patient() {
        short int id;
        id = get_safe_int("\nenter patient id: ", 1, 9999);

        PatientNode* p = patients.search(id);
        if (p) {
            cout << "\n--- patient found ---\n";
            cout << "id: " << p->id << "\nname: " << p->name
                << "\nage: " << p->age << "\nseverity: " << p->severity
                << "\ndisease: " << p->disease << "\ndepartment: " << p->dept_id << "\n";
        }
        else {
            cout << "patient not found!\n";
        }
    }

    void add_to_queue() {
        short int id;
        id = get_safe_int("\nenter patient id to add to queue: ", 1, 9999);

        PatientNode* p = patients.search(id);
        if (p) {
            queue.enqueue(id, p->severity);
        }
        else {
            cout << "patient not found!\n";
        }
    }

    void treat_next_patient() {
        short int patient_id = queue.dequeue();
        if (patient_id == -1) return;

        cout << "treating patient id: " << patient_id << "\n";

        short int doctor_id = patient_doctor[patient_id];

        if (doctor_id != -1) {
            doctor_balancer.release_doctor(doctor_id);

            for (int i = 0; i < doctor_count; i++) {
                if (doctors[i].id == doctor_id && doctors[i].current_load > 0) {
                    doctors[i].current_load--;
                    break;
                }
            }
            patient_doctor[patient_id] = -1;
        }

        history.push("treated patient", patient_id);
    }

    void add_doctor() {
        if (doctor_count >= 100) {
            cout << "doctor limit reached!\n";
            return;
        }

        doctors[doctor_count].id = get_safe_int("\nenter doctor id: ", 1, 9999);
        cin.ignore();
        cout << "enter name: ";
        cin.getline(doctors[doctor_count].name, 50);
        cout << "enter specialization: ";
        cin.getline(doctors[doctor_count].specialization, 50);
        doctors[doctor_count].current_load = 0;
        
        doctor_balancer.add_doctor(doctors[doctor_count]);
        doctor_count++;

        cout << "doctor added successfully!\n";
        save_doctors();
    }

    void load_doctors_from_file() {
        ifstream file("doctors.txt");
        if (!file) return;

        char line[256];

        while (doctor_count < 50 && file.getline(line, 256)) {
            Doctor d;

            char* token = strtok(line, ",");
            if (token) d.id = atoi(token);

            token = strtok(NULL, ",");
            if (token) strcpy(d.name, token);

            token = strtok(NULL, ",");
            if (token) strcpy(d.specialization, token);

            token = strtok(NULL, ",");
            if (token) d.current_load = atoi(token);

            doctors[doctor_count++] = d;
            doctor_balancer.add_doctor(d);
        }
        file.close();
    }

    void assign_doctor_to_patient() {
        short int patient_id;
        patient_id = get_safe_int("\nenter patient id: ", 1, 9999);

        PatientNode* p = patients.search(patient_id);
        if (!p) {
            cout << "patient not found!\n";
            return;
        }

        Doctor d = doctor_balancer.assign_doctor();

        if (d.id == -1) {
            cout << "no doctors available!\n";
            return;
        }

        patient_doctor[patient_id] = d.id;

        for (int i = 0; i < doctor_count; i++) {
            if (doctors[i].id == d.id) {
                doctors[i].current_load = d.current_load;
                break;
            }
        }

        cout << "\ndoctor assigned successfully!\n";
        cout << "doctor id: " << d.id
            << "\nname: " << d.name
            << "\nspecialization: " << d.specialization
            << "\nupdated load: " << d.current_load << endl;

        history.push("doctor assigned", patient_id);
    }

    void view_queue() {
        queue.display();
    }

    void view_all_patients() {
        patients.display_all();
    }

    void show_critical_patients() {
        patients.show_critical_patients();
    }

    void show_disease_analytics() {
        patients.disease_frequency_report();
    }

    void add_referral() {
        short int from, to;
        from = get_safe_int("\nenter source department id: ", 1, 9999);
        to = get_safe_int("enter destination department id: ", 1, 9999);
        referrals.add_referral(from, to, false);
    }

    void load_referrals_from_file() {
        ifstream file("referrals.txt");
        if (!file) return;

        short int u, v;
        while (file >> u >> v) {
            referrals.add_referral(u, v, true); 
        }
        file.close();
    }

    void view_referral_network() {
        referrals.display_graph();
    }

    void traverse_bfs() {
        short int start;
        start = get_safe_int("\nenter starting department id: ", 1, 9999);
        referrals.bfs(start);
    }

    void traverse_dfs() {
        short int start;
        start = get_safe_int("\nenter starting department id: ", 1, 9999);
        referrals.dfs(start);
    }

    void shortest_referral_path() {
        short int start;
        start = get_safe_int("\nenter source department id: ", 1, 9999);
        referrals.dijkstra(start);
    }

    void view_history() {
        history.display();
    }

    void undo_last_action() {
        char action[100];
        short int patient_id;

        if (history.pop(action, patient_id)) {
            cout << "undoing: " << action << " (patient id: " << patient_id << ")\n";
        }
        else {
            cout << "no actions to undo!\n";
        }
    }

    void save_and_exit() {
        patients.save_to_file();
        save_doctors();
        save_departments();
        cout << "data saved. exit.\n";
    }
};

//  MAIN MENU 
int main() {
    HospitalSystem system;
    short int choice;

    while (true) {
        cout << "\n  ---- smart hospital system ---- \n";
        cout << "1. add patient\n";
        cout << "2. delete patient\n";
        cout << "3. search patient\n";
        cout << "4. display all patients\n";
        cout << "5. add doctor\n";
        cout << "6. assign doctor \n";
        cout << "7. add patient to queue\n";
        cout << "8. treat next patient (priority)\n";
        cout << "9. view priority queue\n";
        cout << "10. view critical patients\n";
        cout << "11. disease frequency analytics\n";
        cout << "12. add department referral\n";
        cout << "13. display referral network\n";
        cout << "14. bfs traversal\n";
        cout << "15. dfs traversal\n";
        cout << "16. shortest referral path (dijkstra)\n";
        cout << "17. view action history\n";
        cout << "18. undo last action\n";
        cout << "19. save and exit\n";
        choice = get_safe_int("enter choice: ", 1, 19);

        switch (choice) {
        case 1: system.add_patient(); break;
        case 2: system.delete_patient(); break;
        case 3: system.search_patient(); break;
        case 4: system.view_all_patients(); break;
        case 5: system.add_doctor(); break;
        case 6: system.assign_doctor_to_patient(); break;
        case 7: system.add_to_queue(); break;
        case 8: system.treat_next_patient(); break;
        case 9: system.view_queue(); break;
        case 10: system.show_critical_patients(); break;
        case 11: system.show_disease_analytics(); break;
        case 12: system.add_referral(); break;
        case 13: system.view_referral_network(); break;
        case 14: system.traverse_bfs(); break;
        case 15: system.traverse_dfs(); break;
        case 16: system.shortest_referral_path(); break;
        case 17: system.view_history(); break;
        case 18: system.undo_last_action(); break;
        case 19:
            system.save_and_exit();
            return 0;
        default:
            cout << "invalid choice!\n";
        }
    }
    return 0;
}