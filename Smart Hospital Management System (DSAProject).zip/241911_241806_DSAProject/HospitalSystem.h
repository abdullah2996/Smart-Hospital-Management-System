#ifndef HOSPITALSYSTEM_H
#define HOSPITALSYSTEM_H

#include <iostream>
#include <fstream>
#include <cstring>

using namespace std;

short int get_safe_int(const char* prompt, short int min = -32768, short int max = 32767);

// PATIENT NODE
struct PatientNode {
    short int id;
    char name[50];
    short int age;
    short int severity;
    char disease[100];
    short int dept_id;
    PatientNode* next;
};

// DOCTOR STRUCTURE 
struct Doctor {
    short int id;
    char name[50];
    char specialization[50];
    short int current_load;
};

// DOCTOR LOAD BALANCER (MIN HEAP) 
class DoctorLoadBalancer {
private:
    Doctor heap[100];
    short int size;

    void heapify_up(short int index);
    void heapify_down(short int index);

public:
    DoctorLoadBalancer();
    void add_doctor(Doctor d);
    Doctor assign_doctor();
    void release_doctor(short int doctor_id);
    void display_doctors();
};

// DEPARTMENT STRUCTURE 
struct Department {
    short int id;
    char name[50];
    short int capacity;
    short int current_patients;
};

// PATIENT HASH TABLE 
class PatientHashTable {
private:
    static const short int TABLE_SIZE = 100;
    PatientNode* table[TABLE_SIZE];

    short int hash_function(short int id);

public:
    PatientHashTable();
    void insert(short int id, const char* name, short int age, short int severity, const char* disease, short int dept_id);
    PatientNode* search(short int id);
    bool remove(short int id);
    void show_critical_patients();
    void disease_frequency_report();
    void display_all();
    void save_to_file();
    void load_from_file();
};

// PRIORITY QUEUE (MAX HEAP) 
struct PriorityPatient {
    short int patient_id;
    short int severity;
};

class PriorityQueue {
private:
    PriorityPatient heap[100];
    short int size;

    void heapify_up(short int index);
    void heapify_down(short int index);

public:
    PriorityQueue();
    void enqueue(short int patient_id, short int severity);
    short int dequeue();
    bool is_empty();
    void display();
};

// GRAPH FOR REFERRAL NETWORK 
struct GraphNode {
    short int dept_id;
    GraphNode* next;
};

class ReferralGraph {
private:
    static const short int MAX_DEPT = 10;
    GraphNode* adj_list[MAX_DEPT];

    void dfs_util(short int dept, bool visited[]);

public:
    ReferralGraph();
    void add_referral(short int from, short int to, bool silent = false);
    void display_graph();
    void bfs(short int start);
    void dfs(short int start);
    void dijkstra(short int src);
};

// STACK FOR UNDO 
struct ActionNode {
    char action[100];
    short int patient_id;
    ActionNode* next;
};

class ActionStack {
private:
    ActionNode* top;

public:
    ActionStack();
    void push(const char* action, short int patient_id);
    bool pop(char* action, short int& patient_id);
    void display();
    bool is_empty();
};

// MAIN SYSTEM 
class HospitalSystem {
private:
    PatientHashTable patients;
    Doctor doctors[100];
    DoctorLoadBalancer doctor_balancer;
    Department departments[100];
    PriorityQueue queue;
    ReferralGraph referrals;
    ActionStack history;
    short int doctor_count;
    short int dept_count;
    short int patient_doctor[1000];

    void save_doctors();
    void load_departments();
    void save_departments();

public:
    HospitalSystem();
    void add_patient();
    void delete_patient();
    void search_patient();
    void add_to_queue();
    void treat_next_patient();
    void add_doctor();
    void load_doctors_from_file();
    void assign_doctor_to_patient();
    void view_queue();
    void view_all_patients();
    void show_critical_patients();
    void show_disease_analytics();
    void add_referral();
    void load_referrals_from_file();
    void view_referral_network();
    void traverse_bfs();
    void traverse_dfs();
    void shortest_referral_path();
    void view_history();
    void undo_last_action();
    void save_and_exit();
};

#endif