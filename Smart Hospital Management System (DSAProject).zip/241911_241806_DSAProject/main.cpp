#include "HospitalSystem.h"

// MAIN MENU 
int main() {
    HospitalSystem system;
    short int choice;

    while (true) {
        cout << "\n ---- smart hospital system ---- \n";
        cout << "1. add patient\n";
        cout << "2. delete patient\n";
        cout << "3. search patient\n";
        cout << "4. display all patients\n";
        cout << "5. add doctor\n";
        cout << "6. assign doctor \n";
        cout << "7. add patient to queue\n";
        cout << "8. treat next patient (priority)\n";
        cout << "9. view priority queue\n";
        cout << "10. view critical patients\n";
        cout << "11. disease frequency analytics\n";
        cout << "12. add department referral\n";
        cout << "13. display referral network\n";
        cout << "14. bfs traversal\n";
        cout << "15. dfs traversal\n";
        cout << "16. shortest referral path (dijkstra)\n";
        cout << "17. view action history\n";
        cout << "18. undo last action\n";
        cout << "19. save and exit\n";
        choice = get_safe_int("enter choice: ", 1, 19);

        switch (choice) {
        case 1: system.add_patient(); break;
        case 2: system.delete_patient(); break;
        case 3: system.search_patient(); break;
        case 4: system.view_all_patients(); break;
        case 5: system.add_doctor(); break;
        case 6: system.assign_doctor_to_patient(); break;
        case 7: system.add_to_queue(); break;
        case 8: system.treat_next_patient(); break;
        case 9: system.view_queue(); break;
        case 10: system.show_critical_patients(); break;
        case 11: system.show_disease_analytics(); break;
        case 12: system.add_referral(); break;
        case 13: system.view_referral_network(); break;
        case 14: system.traverse_bfs(); break;
        case 15: system.traverse_dfs(); break;
        case 16: system.shortest_referral_path(); break;
        case 17: system.view_history(); break;
        case 18: system.undo_last_action(); break;
        case 19:
            system.save_and_exit();
            return 0;
        default:
            cout << "invalid choice!\n";
        }
    }
    return 0;
}